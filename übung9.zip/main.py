kelime=input("kelime girin")
harf=input("bir harf girin")

yeni_kelime = kelime.replace(harf, "")


print("yeni  sozcuk" , yeni_kelime)