sozcuk=input("bir sozcuk girin")
print(len(sozcuk))



