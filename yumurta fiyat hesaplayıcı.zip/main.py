toplam_yumurta = int(input("Bu sabah kac yumurta topladiniz? "))
kutu_12 = toplam_yumurta // 12
kalan_yumurta = toplam_yumurta % 12
kutu_6 = kalan_yumurta // 6
kahvaltilik = kalan_yumurta % 6
print()
print("12'lik kutu sayisi:", kutu_12)
print("6'lik kutu sayisi:", kutu_6)
print("Kahvalti icin kalan yumurta sayisi:", kahvaltilik)