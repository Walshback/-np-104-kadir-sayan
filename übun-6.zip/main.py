kelime=input("kelime girin")
sayi=int(input("bir sayi girin"))
harf=input("bir harf giriniz")

kelime= kelime[:sayi] + harf + kelime[sayi+1:]
print("yeni sozcuk" , kelime)