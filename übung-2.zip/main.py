isim=input("adınızı girin")
soyisim=input("soyisminizi girin")
ilkharfler= isim[0].lower() + soyisim.lower[0]
print=(ilkharfler)