sozcuk=input("bir kelime girin")
ilk_son= sozcuk[0]  + sozcuk[-1]
print ("ilk ve son harf", ilk_son)