sozcuk=input("bir kelime girin")
print("ilkharfsilinmis:" ,sozcuk[1:] )