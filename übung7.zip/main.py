kelime=input("kelime girin")

for harf in kelime : 
  print(harf+ "!")