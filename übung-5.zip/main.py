sozcuk=input("bir sozcuk giriniz")
sayi=input("bir sayi giriniz")
if sayi<len(sozcuk):
 sozcuk1= sozcuk[:sayi]
 sozcuk2= sozcuk[sayi:]
 sozcuk=sozcuk1+"-"+sozcuk2
 print(sozcuk)