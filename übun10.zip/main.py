kelime=input("kelime girin")
sesli_harf = "aAeEoOuUiI"
sesli_sayisi=0
for harf in kelime:
  if harf in sesli_harf:
    sesli_sayisi += 1
print("sesli harf sayisi budur," + str(sesli_sayisi))