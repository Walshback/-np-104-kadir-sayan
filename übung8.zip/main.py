kelime=input("kelime girin")
harf=input("bir harf girin")

def_sayisi = kelime.count(harf)

print(def_sayisi)